<?php /* C:\xampp\htdocs\lyson\resources\views/trangchu/chitiet/news.blade.php */ ?>
 <?php $__env->startSection('noidung'); ?>
<!-- Home -->
<div class="home1">
    <div class="home_background1 parallax-window" data-parallax="scroll" data-image-src="travel/images/blog_background.jpg"></div>
    <div class="home_content1">
    </div>
</div>
<!-- Blog -->
<div class="blog">
    <div class="container">
        <div class="row">
            <!-- Blog Content -->
            <div class="col-lg-8">
                <div class="blog_post_container">
                    <!-- Blog Post -->
                    <div class="blog_post">
                        <div class="blog_post_image">
                            <img class="custom-img" src="/<?php echo e($chitiet->img); ?>" alt="du lịch lý sơn">
                            <div class="blog_post_date d-flex flex-column align-items-center justify-content-center">
                                <div class="blog_post_day"><?php echo e($chitiet->id); ?></div>
                                <div class="blog_post_month"><?php echo e(date("d-m-Y", strtotime($chitiet->date))); ?></div>
                            </div>
                        </div>
                        <br>
                        <div class="fb-like" data-href="<?php echo e(route('trangchu.chitiet.news',['slug'=>str_slug($chitiet->tieuDe),'id'=>$chitiet->id])); ?>" data-layout="standard" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
                    </div>
                    <div class="blog_post">
                        <h1 style="font-family: Times, serif;color:black; font-size: 300%;font-weight:700;"><?php echo e($chitiet->tieuDe); ?></h1>
                        <div class="rating_r rating_r_4 hotel_rating">
                            <i></i>
                            <i></i>
                            <i></i>
                            <i></i>
                            <i></i>
                        </div>
                        <div>
                            <?php echo $chitiet->noiDung; ?>

                        </div>
                        <br>
                        <div class="fb-comments" data-href="<?php echo e(route('trangchu.chitiet.news',['slug'=>str_slug($chitiet->tieuDe),'id'=>$chitiet->id])); ?>" data-numposts="5"></div>
                    </div>
                </div>
            </div>
            <!-- Blog Sidebar -->
            <div class="col-lg-4 sidebar_col">
                    <?php echo $__env->make('trangchu.menu.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<br> <?php $__env->stopSection(); ?> <?php $__env->startSection('meta'); ?>
<title><?php echo e($chitiet->title); ?></title>
<meta name="keywords" content="<?php echo e($chitiet->keyword); ?>" />
<meta name="description" content="<?php echo e($chitiet->description); ?>" />
<!--meta facebook-->
<meta property="og:title" content="<?php echo e($chitiet->title); ?>" />
<meta property="og:description" content="<?php echo e($chitiet->description); ?>" />
<meta property="og:image" content="/<?php echo e($chitiet->img); ?>" />
<!--meta google-->
<meta itemprop="name" content="<?php echo e($chitiet->title); ?>" />
<meta itemprop="description" content="<?php echo e($chitiet->description); ?>" />
<meta itemprop="image" content="/<?php echo e($chitiet->img); ?>" />
<meta name="og:url" content="<?php echo e(route('trangchu.chitiet.news',['slug'=>str_slug($chitiet->tieuDe),'id'=>$chitiet->id])); ?>" /> <?php $__env->stopSection(); ?>

<?php echo $__env->make('trangchu.menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>