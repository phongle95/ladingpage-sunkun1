<?php /* C:\xampp\htdocs\sunkun\resources\views/mailfb.blade.php */ ?>
<h3>Tên Khách Hàng : <?php echo e($name); ?></h3>
<br>
<h3>Số Điện Thoại : <?php echo e($sdt); ?></h3>
<br>
<h3>Nội Dung : <?php echo e($noiDung); ?></h3>
